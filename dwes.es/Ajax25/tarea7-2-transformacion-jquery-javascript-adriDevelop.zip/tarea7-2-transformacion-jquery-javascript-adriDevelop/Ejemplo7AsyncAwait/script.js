"use strict"
window.addEventListener("DOMContentLoaded", ()=>{
    mostrarProv();
})

const provincias = document.getElementById('provincias');

const mostrarProv=async() =>{
    try{
        const response= await fetch("https://raw.githubusercontent.com/IagoLast/pselect/master/data/provincias.json")
        const data=await response.json();
        data.sort((a, b) => {
            return a.nm.localeCompare(b.nm)
        })
        //cargar en el select
        // $(data).each((ind, ele) => {
        //     $("#provincias").append("<option id=" + ele.id + ">" + ele.nm + "</option>")
        // })
        data.forEach(elemento => {
            const option = document.createElement('option');
            option.id = elemento.id;
            option.innerText = elemento.nm;
            provincias.appendChild(option);
        })

        //evento change
        // $("#provincias").on("change", function () {
        //     Swal.fire("El Id es " + $("#provincias option:selected").attr("id"))
        // })
        provincias.addEventListener('change', (e) => {
            Swal.fire("El Id es " + e.target.value);
        })
        
    }catch(error){
        console.error(error);
    };
         
}
