"use strict"
window.addEventListener("DOMContentLoaded", ()=>{
    mostrarProv();
})

const provincias = document.getElementById('provincias');

const mostrarProv=() =>{
        fetch("https://raw.githubusercontent.com/IagoLast/pselect/master/data/provincias.json")
         .then((response) =>{ 
            if (response.status==200){
             return response.json();
            }else{
              throw ("Error en la comunicación")
            }
         })
        
         .then((data) => {
            //ordenar ascedente
           
            data.sort((a, b) => {
                return a.nm.localeCompare(b.nm)
            })
            //cargar en el select
            // $(data).each((ind, ele) => {
            //     $("#provincias").append("<option id=" + ele.id + ">" + ele.nm + "</option>")
            // })
            data.forEach((ele) => {
                const option = document.createElement('option');
                option.id = ele.id;
                option.innerText = ele.nm;
                provincias.appendChild(option);
            });

            //evento change
            // $("#provincias").on("change", function () {

            //     Swal.fire("El Id es " + $("#provincias option:selected").attr("id"))
            // })

            provincias.addEventListener('change', (e)=>{
                Swal.fire("El Id es " + e.target.value);
            })
          })
          .catch((error) => {
            console.log(error);
          });
        
      }
