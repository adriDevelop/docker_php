[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/jSCXf1F4)

# Ejercicio 7-2.- Transformación jQuery JavaScript

## Alumno: Adrián Velasco Carrasco

### Ejercicio 1.- Transformación de todo el código jQuery a JavaScript

```javascript 

/* --------------- CÓDIGO JQUERY ----------------- */

//cargar en el select
             $(data).each((ind, ele) => {
                $("#provincias").append("<option id=" + ele.id + ">" + ele.nm + "</option>")
             })

//evento change
            $("#provincias").on("change", function () {

               Swal.fire("El Id es " + $("#provincias option:selected").attr("id"))
            })
```

#### Explicación del código JQuery 

Lo que realiza esté codigo básicamente es un forEach a los elementos que recibe de la respuesta del fetch

Y la segunda parte del código lo que realiza es añadirle un evento al select, en el cual cuando cambie, se muestre una alerta con sweet alert

#### Cambios realizados para pasarlo a JavaScript

```javascript 
    
    /* --------------- CÓDIGO JAVASCRIPT ----------------- */

    // Primero he recogido el option de las provincias del documento
    const provincias = document.getElementById('provincias');

    // Cambio del forEach de jQuery a JavaScript
    data.forEach((ele) => {
                const option = document.createElement('option');
                option.id = ele.id;
                option.innerText = ele.nm;
                provincias.appendChild(option);
            });
    
    // Y aquí el evento cambiado a JavaScript
    provincias.addEventListener('change', (e)=>{
                Swal.fire("El Id es " + e.target.value);
            })

```

### Ejercicio 2.- Transformación de todo el código jQuery a JavaScript

```javascript
/* --------------- CÓDIGO JQUERY ----------------- */

//cargar en el select
         $(data).each((ind, ele) => {
             $("#provincias").append("<option id=" + ele.id + ">" + ele.nm + "</option>")
         })

//evento change
        $("#provincias").on("change", function () {
            Swal.fire("El Id es " + $("#provincias option:selected").attr("id"))
         })
```

#### Explicación del código jQuery

Lo que realiza esté codigo básicamente es un forEach a los elementos que recibe de la respuesta del fetch

Y la segunda parte del código lo que realiza es añadirle un evento al select, en el cual cuando cambie, se muestre una alerta con sweet alert

#### Cambios realizados para pasarlo a JavaScript

```javascript

/* --------------- CÓDIGO JAVASCRIPT ----------------- */

    // Primero he recogido el option de las provincias del documento
    const provincias = document.getElementById('provincias');

    // Cambio del forEach de jQuery a JavaScript
    data.forEach((ele) => {
                const option = document.createElement('option');
                option.id = ele.id;
                option.innerText = ele.nm;
                provincias.appendChild(option);
            });
    
    // Y aquí el evento cambiado a JavaScript
    provincias.addEventListener('change', (e)=>{
                Swal.fire("El Id es " + e.target.value);
            })

```

### Ejercicio 3.- Tranformación de todo el código jQuery a JavaScript

### Explicación del código jQuery

```javascript

/* --------------- CÓDIGO JQUERY ----------------- */
$(() => {
   
        $("#first, #all").on("click", mostrar);
   
})

    $("tbody").empty();
        console.log(data);
           $(data.data).each((ind, ele) => {
             $("tbody").append(`<tr><td>${ele.chip}</td><td>${ele.nombre}</td><td>${ele.raza}</td><td>${ele.fechaNac}</td></tr>`)
            })

```

#### Explicación del código jQuery

Lo que hace este código es al principio de todo, añadirle un evento click a los elementos del dom first y all, llamando a la funcion mostrar.

Tras esto, vacía el tbody, y, por cada elemento, lo añade dentro del tbody en un tr y en un td.

#### Cambios realizados para pasarlo a JavaScript

```javascript

    // Lo primero es obtener del dom los dos elementos 
    const first = document.getElementById('first').addEventListener('click', (e)=>mostrar(e));
    const all = document.getElementById('all').addEventListener('click', (e)=>mostrar(e));

    // Despues, voy creando un td y añadiendolo al tr con cada elemento del element
    const tbody = document.querySelector('tbody');
    console.log(data);
    tbody.innerHTML = '';
    data.forEach(element => {
        const tr = document.createElement('tr');
        
        let td = document.createElement('td');
        td.innerText = element.chip;
        tr.appendChild(td);
        
        td = document.createElement('td');
        td.innerText = element.nombre;
        tr.appendChild(td);
        
        td = document.createElement('td');
        td.innerText = element.raza;
        tr.appendChild(td);
        
        td = document.createElement('td');
        td.innerText = element.fechaNac;
        tr.appendChild(td);
        
        tbody.appendChild(tr);
    });
```