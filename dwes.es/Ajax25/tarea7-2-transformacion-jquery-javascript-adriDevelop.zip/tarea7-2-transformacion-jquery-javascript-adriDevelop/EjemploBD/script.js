"use strict"

const first = document.getElementById('first').addEventListener('click', (e)=>mostrar(e));
const all = document.getElementById('all').addEventListener('click', (e)=>mostrar(e));

function mostrar(e) {
    const param=new FormData();

    if (e.target.id == "first") {
        param.append("perro", "111A")
    }else{
        param.append("perro", "");
    }   
    
    
    fetch("php/mostrar.php",{
        method:'POST',
        body: param 
    })
    .then((response) =>{
        if (response.status==200){
            return response.json();
         }else{
            throw ("Error en la comunicación")
         }
    }) 
    .then((data) => {
      
    //    $("tbody").empty();
    //    console.log(data);
    //        $(data.data).each((ind, ele) => {
    //            $("tbody").append(`<tr><td>${ele.chip}</td><td>${ele.nombre}</td><td>${ele.raza}</td><td>${ele.fechaNac}</td></tr>`)
    //        })
    const tbody = document.querySelector('tbody');
    console.log(data);
    tbody.innerHTML = '';
    data.forEach(element => {
        const tr = document.createElement('tr');
        
        let td = document.createElement('td');
        td.innerText = element.chip;
        tr.appendChild(td);
        
        td = document.createElement('td');
        td.innerText = element.nombre;
        tr.appendChild(td);
        
        td = document.createElement('td');
        td.innerText = element.raza;
        tr.appendChild(td);
        
        td = document.createElement('td');
        td.innerText = element.fechaNac;
        tr.appendChild(td);
        
        tbody.appendChild(tr);
    });
       
     })
     .catch((error) => {
       console.log(error);
     });
}